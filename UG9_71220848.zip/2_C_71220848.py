#case soal 2
cepat = int(input("Masukan kecepatan tempuh :"))
waktu = int(input("Masukan waktu yang diperlukan :"))
#rumus
bensin=cepat*waktu/10
biaya=bensin*15000
#hasil jumlah akhir
print("Teman Anda mengisi bensin sebanyak",bensin,"liter")
print("Biaya yang dikeluarkan untuk mengisi bensin adalah Rp.",biaya)
