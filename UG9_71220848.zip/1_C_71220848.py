#test case 1
nama = input("Masukan nama Anda :")
matkul = input("Masukan mata kuliah :")
grup = input("Masukan grup :")
#rumus
data = ("a","b")
nama = data.index("b","a")
kelompok = grup
print("halo",nama,"A",kelompok)
